using System.Xml.Linq;

using static CutTheRopeDX.Helpers.ParsingHelpers;

namespace CutTheRopeDX.GameMain
{
    internal sealed partial class GameScene
    {
        /// <summary>
        /// Loads a ghost object from XML node data.
        /// </summary>
        /// <param name="xmlNode">The XML node describing the ghost.</param>
        /// <param name="scale">The level scale factor applied to object coordinates.</param>
        /// <param name="offsetX">The base X offset applied to loaded objects.</param>
        /// <param name="offsetY">The base Y offset applied to loaded objects.</param>
        /// <param name="mapOffsetX">The additional map X offset applied during loading.</param>
        /// <param name="mapOffsetY">The additional map Y offset applied during loading.</param>
        private void LoadGhost(XElement xmlNode, float scale, float offsetX, float offsetY, int mapOffsetX, int mapOffsetY)
        {
            float px = (ParseCoordinateIntOrZero(xmlNode.Attribute("x")?.Value) * scale) + offsetX + mapOffsetX;
            float py = (ParseCoordinateIntOrZero(xmlNode.Attribute("y")?.Value) * scale) + offsetY + mapOffsetY;
            float grabRadius = ParseFloatOrZero(xmlNode.Attribute("radius")?.Value);
            if (grabRadius != -1f)
            {
                grabRadius *= scale;
            }
            float bouncerAngle = ParseFloatOrZero(xmlNode.Attribute("angle")?.Value);
            _ = bool.TryParse(xmlNode.Attribute("grab")?.Value, out bool useGrab);
            _ = bool.TryParse(xmlNode.Attribute("bubble")?.Value, out bool useBubble);
            _ = bool.TryParse(xmlNode.Attribute("bouncer")?.Value, out bool useBouncer);
            GhostForm possibleForms = (useBouncer ? GhostForm.Bouncer : GhostForm.None)
                | (useBubble ? GhostForm.Bubble : GhostForm.None)
                | (useGrab ? GhostForm.Grab : GhostForm.None);
            Ghost ghost = new Ghost().InitWithPositionPossibleFormsGrabRadiusBouncerAngleBubblesBungeesBouncers(
                Vect(px, py),
                possibleForms,
                grabRadius,
                bouncerAngle,
                bubbles,
                bungees,
                bouncers,
                this);
            ghosts.Add(ghost);
        }
    }
}
